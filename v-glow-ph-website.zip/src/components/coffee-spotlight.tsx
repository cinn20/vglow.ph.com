"use client";

import Image from "next/image";
import Link from "next/link";
import type { Product } from "@/db/schema";
import { useCart } from "@/components/cart/cart-context";
import { defaultSizeFor } from "@/lib/product";
import { formatMoney } from "@/lib/pricing";

export function CoffeeSpotlight({ product }: { product: Product }) {
  const { addItem } = useCart();
  const size = defaultSizeFor(product);
  const compareAt = size?.compareAtCents ?? product.compareAtCents;

  function addCoffee() {
    if (!size || product.stock <= 0) return;
    addItem({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      size: size.label,
      image: product.images[0],
      unitPriceCents: size.priceCents,
      compareAtCents: compareAt,
      maxQuantity: Math.min(10, product.stock),
    });
  }

  return (
    <section className="container-luxe pt-10 md:pt-16" aria-labelledby="coffee-spotlight-title">
      <div className="relative grid overflow-hidden border border-[#e6d4bc] bg-[#f3e9dc] lg:grid-cols-2">
        <div className="relative order-2 flex flex-col justify-center px-6 py-9 sm:px-10 md:py-12 lg:order-1 lg:px-14">
          <div className="flex items-center gap-3">
            <span className="h-px w-8 bg-gold" />
            <p className="eyebrow">New at V Glow PH · Your coffee ritual</p>
          </div>
          <h2
            id="coffee-spotlight-title"
            className="mt-4 max-w-lg font-display text-[clamp(2.2rem,4.2vw,3.6rem)] leading-[1.02] text-espresso"
          >
            Your glow, with a little <span className="italic text-gold">coffee.</span>
          </h2>
          <p className="mt-4 text-[10px] uppercase tracking-[0.22em] text-espresso">
            Luxxe White+ Health &amp; Beauty Coffee
          </p>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-mocha">
            A delicious butterscotch coffee blend with premium Japan collagen,
            L-glutathione and L-carnitine. Your favourite little moment, ready to enjoy hot or iced.
          </p>
          <div className="mt-5 flex flex-wrap gap-2">
            {["10 sachets", "Collagen + glutathione", "Sweetened with stevia"].map((detail) => (
              <span
                key={detail}
                className="border border-gold/25 bg-ivory/50 px-3 py-1.5 text-[9px] uppercase tracking-[0.14em] text-espresso/80"
              >
                {detail}
              </span>
            ))}
          </div>
          <div className="mt-6 flex flex-wrap items-center gap-x-3 gap-y-2">
            <span className="font-display text-3xl leading-none text-espresso">
              {formatMoney(product.priceCents)}
            </span>
            {compareAt && compareAt > product.priceCents && (
              <>
                <span className="text-sm text-mocha line-through">{formatMoney(compareAt)}</span>
                <span className="bg-[#7f352c] px-2.5 py-1 text-[9px] uppercase tracking-[0.16em] text-white">
                  Save {formatMoney(compareAt - product.priceCents)}
                </span>
              </>
            )}
            <span className="text-[10px] uppercase tracking-[0.12em] text-mocha">per box</span>
          </div>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <button
              type="button"
              onClick={addCoffee}
              disabled={!size || product.stock <= 0}
              className="btn btn-primary px-8"
            >
              {product.stock <= 0 ? "Sold out" : "Add coffee to bag"}
            </button>
            <Link href={`/products/${product.slug}`} className="btn btn-outline px-8">
              Discover the coffee
            </Link>
          </div>
          <p className="mt-4 text-[10px] leading-relaxed text-mocha">
            10 sachets × 14 g · Contains caffeine. See the product page for details.
          </p>
        </div>
        <Link
          href={`/products/${product.slug}`}
          aria-label={`View ${product.name}`}
          className="group relative order-1 block aspect-[5/4] overflow-hidden bg-[#f4ece1] lg:order-2 lg:aspect-auto lg:min-h-[470px]"
        >
          <Image
            src={product.images[0]}
            alt="A box and sachet of Luxxe White+ Coffee"
            fill
            sizes="(min-width: 1024px) 50vw, 100vw"
            className="object-contain transition-transform duration-[1200ms] ease-out group-hover:scale-[1.04]"
          />
          <span className="absolute right-4 top-4 border border-espresso/10 bg-ivory/90 px-3 py-2 text-[9px] uppercase tracking-[0.16em] text-espresso backdrop-blur">
            10 sachets · On sale
          </span>
        </Link>
      </div>
    </section>
  );
}
