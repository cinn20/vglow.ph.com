import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import JSZip from "jszip";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const ROOT_FILES = [
  "README.md",
  ".env.example",
  "package.json",
  "package-lock.json",
  "tsconfig.json",
  "next.config.ts",
  "postcss.config.mjs",
  "eslint.config.mjs",
  "drizzle.config.ts",
];
const SOURCE_DIRECTORIES = ["src", "public"];
const EXCLUDED_DIRECTORIES = new Set([
  "node_modules", ".next", ".git", ".vercel", "coverage", "dist", "build", "downloads",
]);
const EXCLUDED_EXTENSIONS = /\.(?:pem|key|p12|pfx|sqlite|sqlite3|db|log|zip|bak)$/i;
const BINARY_EXTENSIONS = /\.(?:jpe?g|png|webp|gif|woff2?|ico|pdf)$/i;

async function addDirectory(zip: JSZip, root: string, relativeDirectory: string): Promise<void> {
  const entries = await readdir(
    /*turbopackIgnore: true*/ path.join(/*turbopackIgnore: true*/ root, relativeDirectory),
    { withFileTypes: true },
  );
  for (const entry of entries) {
    if (entry.name.startsWith(".") || EXCLUDED_DIRECTORIES.has(entry.name) || entry.isSymbolicLink()) {
      continue;
    }
    const relativePath = path.join(relativeDirectory, entry.name);
    if (entry.isDirectory()) {
      await addDirectory(zip, root, relativePath);
    } else if (entry.isFile() && !EXCLUDED_EXTENSIONS.test(entry.name)) {
      const content = await readFile(
        /*turbopackIgnore: true*/ path.join(/*turbopackIgnore: true*/ root, relativePath),
      );
      zip.file(relativePath.split(path.sep).join("/"), content, {
        binary: true,
        compression: BINARY_EXTENSIONS.test(entry.name) ? "STORE" : "DEFLATE",
      });
    }
  }
}

async function createArchive(): Promise<Uint8Array> {
  const root = process.cwd();
  const zip = new JSZip();
  for (const file of ROOT_FILES) {
    const content = await readFile(
      /*turbopackIgnore: true*/ path.join(/*turbopackIgnore: true*/ root, file),
    );
    zip.file(file, content, { binary: true });
  }
  for (const directory of SOURCE_DIRECTORIES) {
    await addDirectory(zip, root, directory);
  }
  return zip.generateAsync({
    type: "uint8array",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
    platform: "UNIX",
  });
}

// Source files are immutable in a production deployment. Share the work
// across concurrent download requests and retry if generation fails.
let archivePromise: Promise<Uint8Array> | null = null;
function getArchive() {
  if (!archivePromise) {
    archivePromise = createArchive().catch((error) => {
      archivePromise = null;
      throw error;
    });
  }
  return archivePromise;
}

export async function GET() {
  try {
    const archive = await getArchive();
    const body = new Uint8Array(archive.byteLength);
    body.set(archive);
    return new Response(body, {
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": 'attachment; filename="v-glow-ph-website.zip"',
        "Content-Length": String(body.byteLength),
        "Cache-Control": "private, no-store",
        "X-Content-Type-Options": "nosniff",
        "X-Robots-Tag": "noindex, nofollow",
      },
    });
  } catch (error) {
    console.error("Website archive could not be generated:", error);
    return Response.json({ error: "The website download is temporarily unavailable." }, { status: 500 });
  }
}
