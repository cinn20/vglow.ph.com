import { getProductsByIds } from "@/lib/data";

export const dynamic = "force-dynamic";

/** Resolve a saved cart against current product options and server-side prices. */
export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => null);
    if (!Array.isArray(body?.items) || body.items.length > 100) {
      return Response.json({ error: "Invalid bag." }, { status: 400 });
    }

    const entries: { productId: number; size: string }[] = body.items
      .filter((entry: unknown) => {
        if (!entry || typeof entry !== "object") return false;
        const item = entry as { productId?: unknown; size?: unknown };
        return Number.isInteger(item.productId) && Number(item.productId) > 0 &&
          typeof item.size === "string" && item.size.length <= 80;
      })
      .map((entry: { productId: number; size: string }) => ({
        productId: entry.productId,
        size: entry.size,
      }));

    const catalog = await getProductsByIds([...new Set(entries.map((entry) => entry.productId))]);
    const byId = new Map(catalog.map((product) => [product.id, product]));
    const lines = entries.map((entry) => {
      const id = `${entry.productId}:${entry.size}`;
      const product = byId.get(entry.productId);
      const size = product?.sizes.find((option) => option.label === entry.size);
      if (!product || !size || product.stock <= 0) return { id, available: false as const };
      return {
        id,
        available: true as const,
        productId: product.id,
        slug: product.slug,
        name: product.name,
        size: size.label,
        image: product.images[0] || "/images/products/soap.jpg",
        unitPriceCents: size.priceCents,
        compareAtCents: size.compareAtCents ?? product.compareAtCents ?? null,
        maxQuantity: Math.min(10, product.stock),
      };
    });

    return Response.json({ lines });
  } catch {
    return Response.json({ error: "Could not refresh the bag." }, { status: 500 });
  }
}
