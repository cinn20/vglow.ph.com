import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Download your website",
  description: "Download the V Glow PH storefront source code and assets as a ZIP archive.",
  robots: { index: false, follow: true },
};

const inclusions = [
  {
    number: "01",
    title: "The complete storefront",
    body: "Responsive pages, product galleries, search, filters, the shopping bag, and checkout — ready to edit.",
  },
  {
    number: "02",
    title: "Your product catalog",
    body: "The Luxxe White, By Aivee, and Cavella catalog snapshot, plus locally stored product photos.",
  },
  {
    number: "03",
    title: "A real foundation",
    body: "Next.js, PostgreSQL, and Drizzle schema and seed data, with a step-by-step setup guide.",
  },
  {
    number: "04",
    title: "Private by design",
    body: "Environment secrets, installed dependencies, build files, and customer records are not included.",
  },
];

const steps = [
  {
    number: "01",
    title: "Download & unzip",
    body: "Save the ZIP to your computer, extract it, and open the folder in your code editor or terminal.",
    code: null,
  },
  {
    number: "02",
    title: "Install & connect",
    body: "Install the dependencies, then copy .env.example to .env and add your PostgreSQL connection URL.",
    code: "npm ci",
  },
  {
    number: "03",
    title: "Create & run",
    body: "Apply the database schema and start the local server. The demo catalog seeds on your first visit.",
    code: "npx drizzle-kit push  ·  npm run dev",
  },
];

const faqs = [
  {
    question: "What exactly am I downloading?",
    answer:
      "A ZIP containing the V Glow PH website source code, the local product and campaign images, the catalog snapshot, database schema, and a README with setup instructions. It is a Next.js application, not a single static HTML file.",
  },
  {
    question: "Are my customer records or passwords included?",
    answer:
      "No. Your environment files, passwords, PostgreSQL data, orders, customers, installed dependencies, and build output are excluded. The package includes an example environment file with placeholders only.",
  },
  {
    question: "Can I accept real payments straight away?",
    answer:
      "The current checkout is a demonstration: it records orders but does not capture payments, send emails, or arrange delivery. Connect and test your payment provider, email service, fulfillment, security, tax, and privacy processes before selling.",
  },
  {
    question: "Will the product prices update automatically?",
    answer:
      "No. The Velorian catalog is a snapshot, not a live supplier connection. Review product information, rights, prices, and availability before publishing or selling. Time-limited source offers stop appearing after their recorded end time.",
  },
];

function DownloadIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
      <path d="M12 3v12m0 0 4-4m-4 4-4-4M4 17v3h16v-3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function DownloadPage() {
  return (
    <div>
      <section className="relative overflow-hidden border-b border-ink/10 bg-cream">
        <div className="pointer-events-none absolute -right-24 -top-32 h-96 w-96 rounded-full border border-gold/20" />
        <div className="container-luxe grid items-center gap-10 py-12 md:py-16 lg:grid-cols-[1fr_0.85fr] lg:gap-20 lg:py-20">
          <div className="relative z-10">
            <nav className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-mocha">
              <Link href="/" className="transition hover:text-ink">Home</Link>
              <span>/</span>
              <span className="text-espresso">Download</span>
            </nav>
            <div className="mt-8 flex items-center gap-3">
              <span className="h-px w-9 bg-gold" />
              <p className="eyebrow">Your website, yours to keep</p>
            </div>
            <h1 className="mt-4 font-display text-[clamp(2.8rem,6vw,4.6rem)] leading-[0.98] text-espresso">
              Take V Glow PH
              <span className="block italic text-gold">with you.</span>
            </h1>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-mocha">
              Download the complete storefront source, product imagery and catalog in one convenient
              ZIP. Make it yours, run it locally, or prepare it for your own hosting.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href="/api/download" download="v-glow-ph-website.zip" className="btn btn-primary px-8">
                <DownloadIcon />
                Download website ZIP
              </a>
              <a href="#setup" className="btn btn-outline px-8">View setup guide</a>
            </div>
            <p className="mt-4 text-[11px] leading-relaxed text-mocha">
              Source code &amp; images · ZIP archive · No passwords or customer data
            </p>
          </div>

          <div className="relative mx-auto w-full max-w-[470px] animate-fade-up">
            <div className="absolute -left-4 -top-4 h-full w-full border border-gold/25" />
            <div className="relative overflow-hidden border border-ink/10 bg-ivory p-6 shadow-soft sm:p-8">
              <div className="flex items-start justify-between border-b border-ink/10 pb-6">
                <div>
                  <p className="font-display text-3xl tracking-[0.13em] text-espresso">V GLOW</p>
                  <p className="mt-1 text-[9px] uppercase tracking-[0.3em] text-gold">Philippines · Website files</p>
                </div>
                <span className="flex h-11 w-11 items-center justify-center rounded-full border border-gold/40 text-gold">
                  <DownloadIcon />
                </span>
              </div>
              <p className="mt-7 font-display text-2xl leading-tight text-espresso">Everything in one place.</p>
              <p className="mt-2 text-sm leading-relaxed text-mocha">
                Your storefront, carefully packaged and ready for the next chapter.
              </p>
              <ul className="mt-6 space-y-3 border-y border-ink/10 py-5">
                {[
                  ["01", "Website source & components"],
                  ["02", "Product photos & catalog"],
                  ["03", "Database schema & setup guide"],
                ].map(([number, label]) => (
                  <li key={number} className="flex items-center gap-3 text-[12px] text-espresso">
                    <span className="font-display text-base text-gold">{number}</span>
                    {label}
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex items-center justify-between gap-3">
                <span className="text-[10px] uppercase tracking-[0.18em] text-mocha">v-glow-ph-website.zip</span>
                <span className="bg-gold/15 px-2.5 py-1 text-[9px] uppercase tracking-[0.16em] text-gold">Ready</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container-luxe py-16 md:py-24">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <p className="eyebrow">Thoughtfully packaged</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3rem)] leading-[1.03]">
              What&apos;s inside the ZIP.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-mocha">
            Everything needed to continue building your website, without the files that should stay private.
          </p>
        </div>
        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {inclusions.map((item) => (
            <div key={item.number} className="border border-ink/10 bg-white/50 p-5 md:p-6">
              <p className="font-display text-3xl text-gold/60">{item.number}</p>
              <h3 className="mt-4 font-display text-xl leading-tight text-espresso">{item.title}</h3>
              <p className="mt-2 text-[13px] leading-relaxed text-mocha">{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="setup" className="scroll-mt-28 bg-parchment/50 py-16 md:py-24">
        <div className="container-luxe grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
          <div>
            <p className="eyebrow">A simple start</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3rem)] leading-[1.03]">
              Make yourself at home.
            </h2>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-mocha">
              You&apos;ll need Node.js 20.9 or newer and a PostgreSQL database. The included README
              explains every step in more detail.
            </p>
            <Link href="/shop" className="link-underline mt-6 text-[10px] uppercase tracking-[0.2em] text-espresso">
              Back to the storefront
            </Link>
          </div>
          <div className="divide-y divide-ink/10 border-y border-ink/10">
            {steps.map((step) => (
              <div key={step.number} className="grid grid-cols-[40px_1fr] gap-4 py-6">
                <span className="font-display text-2xl text-gold">{step.number}</span>
                <div>
                  <h3 className="font-display text-2xl text-espresso">{step.title}</h3>
                  <p className="mt-1.5 max-w-xl text-[13px] leading-relaxed text-mocha">{step.body}</p>
                  {step.code && (
                    <p className="mt-3 inline-block max-w-full overflow-x-auto border border-ink/10 bg-ivory px-3 py-2 font-mono text-[11px] text-espresso">
                      {step.code}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container-luxe py-16 md:py-24">
        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:gap-20">
          <div>
            <p className="eyebrow">Good to know</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3rem)] leading-[1.03]">
              Before you download.
            </h2>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-mocha">
              A few helpful details about what is included and what to prepare before launching.
            </p>
          </div>
          <div className="border-t border-ink/10">
            {faqs.map((faq) => (
              <details key={faq.question} className="group border-b border-ink/10">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-5 text-[13px] text-espresso">
                  {faq.question}
                  <span className="text-gold transition group-open:rotate-45">＋</span>
                </summary>
                <p className="pb-5 text-[13px] leading-relaxed text-mocha">{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="container-luxe pb-4">
        <div className="relative overflow-hidden bg-espresso px-6 py-12 text-center text-ivory md:px-12 md:py-16">
          <div className="pointer-events-none absolute -left-24 -top-32 h-72 w-72 rounded-full border border-gold/20" />
          <div className="relative">
            <p className="eyebrow text-gold-soft">Ready when you are</p>
            <h2 className="mt-3 font-display text-[clamp(2rem,4vw,3rem)] leading-tight">Your next chapter starts here.</h2>
            <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-ivory/60">
              Take the storefront with you and build something beautiful.
            </p>
            <a href="/api/download" download="v-glow-ph-website.zip" className="btn btn-ivory mt-7">
              <DownloadIcon /> Download website ZIP
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
