export const categories = [
  { slug: "coffee", label: "Coffee & Wellness" },
  { slug: "capsules", label: "Capsules" },
  { slug: "soaps", label: "Soaps & Bars" },
  { slug: "sets", label: "Sets & Bundles" },
  { slug: "creams", label: "Creams" },
  { slug: "makeup", label: "Makeup" },
  { slug: "lip-care", label: "Lip Care" },
  { slug: "hair-care", label: "Hair Care" },
  { slug: "food", label: "Food & Spreads" },
  { slug: "serums", label: "Serums & Ampoules" },
  { slug: "masks", label: "Masks & Treatments" },
  { slug: "sun-care", label: "Sun Care" },
];

export const concerns = [
  { slug: "dullness", label: "Dullness" },
  { slug: "dark-spots", label: "Dark spots" },
  { slug: "uneven-tone", label: "Uneven tone" },
  { slug: "acne-marks", label: "Acne marks" },
  { slug: "dryness", label: "Dryness" },
  { slug: "fine-lines", label: "Fine lines" },
];
