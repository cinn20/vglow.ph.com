import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "./index";
import { products, reviews } from "./schema";
import { seedProducts } from "./seed-data";
import { velorianLegacyImages } from "./velorian-import";

function daysAgoDate(days: number) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return date;
}

const capsuleSlugsWithNewPhotos = new Set([
  "luxxe-white-ultima",
  "luxxe-white-protect",
  "luxxe-white-renew",
  "luxxe-white-slim",
]);

/** Add missing products and replace known legacy placeholders without affecting customer data. */
export async function seedDatabase() {
  const existing = await db.select({ slug: products.slug }).from(products);
  const existingSlugs = new Set(existing.map((product) => product.slug));
  let insertedCount = 0;

  for (const product of seedProducts) {
    if (existingSlugs.has(product.slug)) {
      const sourceLegacyImages = velorianLegacyImages[product.slug];
      if (sourceLegacyImages) {
        // Apply the copied retail catalog once to known legacy listings, while
        // preserving IDs, reviews, inventory, and any historical orders.
        await db
          .update(products)
          .set({
            name: product.name,
            subtitle: product.subtitle,
            tagline: product.tagline,
            description: product.description,
            ritual: product.ritual,
            ingredients: product.ingredients,
            benefits: product.benefits,
            concerns: product.concerns,
            images: product.images,
            sizes: product.sizes,
            priceCents: product.priceCents,
            compareAtCents: product.compareAtCents ?? null,
          })
          .where(
            and(
              eq(products.slug, product.slug),
              inArray(sql<string>`${products.images}->>0`, sourceLegacyImages),
            ),
          );
        continue;
      }
      // Upgrade only listings still using the old generic photos. Keep any
      // merchant-customised photos, prices, inventory, reviews, product IDs,
      // and order history intact.
      const legacyImage =
        product.collection === "skin-bars"
          ? "/images/products/soap.jpg"
          : capsuleSlugsWithNewPhotos.has(product.slug)
            ? "/images/products/capsules.jpg"
            : null;
      if (legacyImage) {
        await db
          .update(products)
          .set({
            name: product.name,
            subtitle: product.subtitle,
            tagline: product.tagline,
            description: product.description,
            ritual: product.ritual,
            ingredients: product.ingredients,
            benefits: product.benefits,
            concerns: product.concerns,
            images: product.images,
          })
          .where(
            and(
              eq(products.slug, product.slug),
              sql`${products.images}->>0 = ${legacyImage}`,
            ),
          );
      }
      continue;
    }

    const ratings = product.reviews.map((review) => review.rating);
    const ratingAverage = ratings.length
      ? (ratings.reduce((total, value) => total + value, 0) / ratings.length).toFixed(2)
      : "5.00";

    // A unique slug and a transaction keep concurrent workers from creating
    // duplicate products or partially seeded reviews.
    const inserted = await db.transaction(async (tx) => {
      const [row] = await tx
        .insert(products)
        .values({
          slug: product.slug,
          name: product.name,
          subtitle: product.subtitle,
          collection: product.collection,
          category: product.category,
          tagline: product.tagline,
          description: product.description,
          ritual: product.ritual,
          ingredients: product.ingredients,
          benefits: product.benefits,
          concerns: product.concerns,
          images: product.images,
          sizes: product.sizes,
          priceCents: product.priceCents,
          compareAtCents: product.compareAtCents ?? null,
          badge: product.badge ?? null,
          stock: product.stock,
          rating: ratingAverage,
          reviewCount: product.reviews.length,
          isFeatured: product.isFeatured ?? false,
          isBestseller: product.isBestseller ?? false,
          isNew: product.isNew ?? false,
          sortOrder: product.sortOrder,
        })
        .onConflictDoNothing({ target: products.slug })
        .returning({ id: products.id });

      if (!row) return false;

      if (product.reviews.length > 0) {
        await tx.insert(reviews).values(
          product.reviews.map((review) => ({
            productId: row.id,
            authorName: review.authorName,
            authorLocation: review.authorLocation,
            rating: review.rating,
            title: review.title,
            body: review.body,
            isVerified: review.isVerified ?? true,
            helpfulCount: review.helpfulCount ?? 0,
            createdAt: daysAgoDate(review.daysAgo),
          })),
        );
      }
      return true;
    });

    if (inserted) insertedCount += 1;
  }

  // Update legacy references to the renamed 03 bar without replacing any
  // other product copy or customer data.
  await db
    .update(products)
    .set({
      ritual: sql`replace(${products.ritual}, ${"03 Celebrity soap"}, ${"03 Orange Papaya bar"})`,
    })
    .where(
      and(
        eq(products.slug, "luxxe-white-slim"),
        sql`${products.ritual} like ${"%03 Celebrity soap%"}`,
      ),
    );

  await db
    .update(products)
    .set({
      ingredients: sql`replace(replace(${products.ingredients}, ${"01 Skin Whitening Soap"}, ${"01 Skin Whitening Bar"}), ${"03 Celebrity Soap"}, ${"03 Orange Papaya Bar"})`,
    })
    .where(
      and(
        eq(products.slug, "luxxe-white-ultima-glow-bundle"),
        sql`${products.ingredients} like ${"%03 Celebrity Soap%"}`,
      ),
    );

  return { seeded: insertedCount > 0, products: existing.length + insertedCount };
}

let seedPromise: Promise<{ seeded: boolean; products: number }> | null = null;

/** Ensure the catalog exists and add any newly introduced seed products. */
export async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = seedDatabase().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
