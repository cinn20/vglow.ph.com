import snapshot from "./velorian-catalog.json";
import type { SeedProduct } from "./seed-data";

export type VelorianItem = (typeof snapshot.items)[number];

const itemBySlug = new Map(snapshot.items.map((item) => [item.slug, item]));
const itemById = new Map(snapshot.items.map((item) => [item.id, item]));

export function getVelorianItem(slug: string) {
  return itemBySlug.get(slug) ?? null;
}

/** The source shop timestamps are recorded with the Philippine UTC offset. */
export function isVelorianItemAvailable(slug: string, now = Date.now()) {
  const item = itemBySlug.get(slug);
  if (!item) return true;
  if (item.startsAt && now < Date.parse(item.startsAt)) return false;
  if (item.endsAt && now >= Date.parse(item.endsAt)) return false;
  return true;
}

export function inactiveVelorianSlugs(now = Date.now()) {
  return snapshot.items
    .filter((item) => !isVelorianItemAvailable(item.slug, now))
    .map((item) => item.slug);
}

/** Known old product images, used to apply the source update just once. */
export const velorianLegacyImages: Record<string, string[]> = {
  "luxxe-white-ultima": ["/images/products/luxxe-ultima.jpg", "/images/products/capsules.jpg"],
  "luxxe-white-protect": ["/images/products/luxxe-protect.jpg", "/images/products/capsules.jpg"],
  "luxxe-white-renew": ["/images/products/luxxe-renew.jpg", "/images/products/capsules.jpg"],
  "luxxe-white-slim": ["/images/products/luxxe-slim.jpg", "/images/products/capsules.jpg"],
  "luxxe-white-01-skin-whitening-soap": ["/images/products/luxxe-white-bar-01.jpg", "/images/products/soap.jpg"],
  "luxxe-white-02-oatmeal-exfoliant-bar": ["/images/products/luxxe-white-bar-02.jpg", "/images/products/soap.jpg"],
  "luxxe-white-03-celebrity-soap": ["/images/products/luxxe-white-bar-03.jpg", "/images/products/soap.jpg"],
  "aivee-crystal-mask": ["/images/products/mask.jpg"],
  "aivee-skin-white-soap": ["/images/products/soap.jpg"],
};

function getSize(item: VelorianItem) {
  if (item.id === 185) return "2 boxes · Buy 1 Take 1";
  if (item.id === 241) return "120 bars";
  if (item.id === 47) return "30 capsules";
  if (item.id === 242) return "1 kg jar";
  if (item.id === 243) return "300 g jar";
  if (item.id === 244) return "200 g jar";
  const shade = item.name.match(/#\s*(\d+)/);
  if (shade) return `Shade #${shade[1]}`;
  if (item.category === "soaps") return "1 bar";
  return "1 item";
}

function subtitle(item: VelorianItem) {
  if (item.id === 185) return "Buy 1 take 1 · Two boxes of coffee";
  if (item.id === 241) return "01, 02 & 03 Skin Bars · 120-piece bundle";
  if (item.id === 47) return "Glutathione + Collagen · 30 capsules";
  if (item.category === "food") return `Pistachio cream · ${getSize(item)}`;
  if (item.category === "hair-care") {
    return `Hair touch-up cushion · ${item.name.toLowerCase().includes("black") ? "Natural Black" : "Dark Brown"}`;
  }
  if (item.category === "lip-care") return "Overnight lip mask · Shea butter";
  if (item.category === "makeup") {
    const shade = item.name.match(/#\s*(\d+)/);
    if (shade) return `Lip colour · Shade #${shade[1]}`;
    if (item.name.toLowerCase().includes("blush")) return "Buildable blush balm";
    return "Complexion cushion · Beige";
  }
  if (item.category === "soaps") return "Face & body cleansing bar";
  return item.sourceCategory;
}

function productDescription(item: VelorianItem) {
  if (item.id === 185) {
    return "Enjoy two boxes of Luxxe White+ Health & Beauty Coffee for ₱488. Each box contains individually packed coffee sachets. This buy-one-take-one promotion is available until November 5, 2026 at 12:15 AM Philippine time, while available.";
  }
  if (item.id === 47) {
    return "Luxxe White Ultima combines glutathione and collagen in an individually sold 30-capsule bottle. Choose the smaller bottle for your daily wellness routine. Food supplement, not a medicine.";
  }
  return item.description || `${item.name} is available individually from the Velorian collection at V Glow PH.`;
}

function instructions(item: VelorianItem) {
  if (item.category === "food") {
    return "Enjoy as directed on the packaging. Check the label for the full ingredient list, allergens, and storage instructions.";
  }
  if (item.category === "coffee") {
    return "Prepare each sachet according to the directions on the box. Contains caffeine. If pregnant, nursing, taking medication or sensitive to caffeine, consult a healthcare professional before use.";
  }
  if (item.category === "capsules") {
    return "Follow the directions on the product label. Consult a healthcare professional before use if pregnant, breastfeeding, taking medication or managing a health condition. Food supplement, not a medicine.";
  }
  return "Use as directed on the product packaging. For external use only. Patch test before use and discontinue if irritation occurs.";
}

function ingredientText(item: VelorianItem) {
  const active = item.description.match(/(?:Active Ingredients?|Key Ingredients?)\s*:\s*([\s\S]{1,500})/i);
  if (active) return `${active[1].trim()}\nRefer to the packaging for the complete ingredient list.`;
  return item.category === "food"
    ? "Please check the jar for the complete ingredient list and allergen information, including nuts and any other declared allergens."
    : "Please refer to the product packaging for the complete ingredient list and any warnings.";
}

function newProduct(item: VelorianItem): SeedProduct {
  const size = getSize(item);
  const categoryTag = item.collection === "aivee" ? "By Aivee" : item.sourceCategory;
  return {
    slug: item.slug,
    name: item.name,
    subtitle: subtitle(item),
    collection: item.collection,
    category: item.category,
    tagline: item.category === "food" ? "A little indulgence for every day." : "A little something for your routine.",
    description: productDescription(item),
    ritual: instructions(item),
    ingredients: ingredientText(item),
    benefits: [
      `${categoryTag} collection`,
      item.id === 185 ? "Includes two boxes of coffee" : `Available as ${size.toLowerCase()}`,
      "Product details and directions are on the packaging",
    ],
    concerns: [],
    images: [item.image],
    sizes: [{ label: size, priceCents: item.priceCents }],
    priceCents: item.priceCents,
    badge: item.endsAt ? "Limited offer" : undefined,
    stock: 100,
    isNew: false,
    sortOrder: item.id === 185 ? 0 : item.id === 47 ? 2 : 30 + item.sourceOrder,
    reviews: [],
  };
}

function sourceSizes(item: VelorianItem) {
  if (item.id === 46) {
    const trialPrice = itemById.get(47)?.priceCents ?? 168000;
    return [
      { label: "60 capsules", priceCents: item.priceCents },
      { label: "30 capsules", priceCents: trialPrice },
    ];
  }
  if (item.id === 48) {
    return [
      { label: "45 capsules", priceCents: item.priceCents },
      { label: "45 capsules × 2", priceCents: item.priceCents * 2 },
    ];
  }
  if (item.id === 49 || item.id === 50) return [{ label: "60 capsules", priceCents: item.priceCents }];
  if ([20, 21, 22].includes(item.id)) {
    return [
      { label: "135 g bar", priceCents: item.priceCents },
      { label: "3-bar bundle", priceCents: item.priceCents * 3 },
    ];
  }
  if (item.id === 264) {
    return [
      { label: "5 sheets", priceCents: item.priceCents },
      { label: "10 sheets", priceCents: item.priceCents * 2 },
    ];
  }
  if (item.id === 266) {
    return [
      { label: "1 bar", priceCents: item.priceCents },
      { label: "3-bar bundle", priceCents: item.priceCents * 3 },
    ];
  }
  return [{ label: getSize(item), priceCents: item.priceCents }];
}

function sourceExistingProduct(product: SeedProduct, item: VelorianItem): SeedProduct {
  const gallery = [item.image, ...product.images.filter((image) => image !== item.image).slice(0, 2)];
  const sourceDescription = item.id === 264 || item.id === 266 ? item.description : product.description;
  return {
    ...product,
    name: item.name,
    tagline: item.id === 266 ? "A simple addition to your daily cleanse." : product.tagline,
    subtitle:
      item.id === 46 ? "Glutathione + Collagen · 60 capsules" :
      item.id === 48 ? "Pure Grape Seed Extract · 45 capsules" :
      item.id === 49 ? "Glutathione + Pure Barley · 60 capsules" :
      item.id === 50 ? "Glutathione + L-Carnitine · 60 capsules" :
      item.id === 264 ? "Bio-cellulose sheet mask · 5 sheets" :
      item.id === 266 ? "Glutathione cleansing bar · Face & body" : product.subtitle,
    description: sourceDescription,
    ritual: item.id === 264 && item.description.includes("DIRECTIONS:")
      ? item.description.split("DIRECTIONS:")[1].trim()
      : product.ritual,
    ingredients: item.id === 264
      ? "Key ingredients include niacinamide, alpha arbutin and coconut water. Please refer to the packaging for the complete ingredient list."
      : item.id === 266
        ? "Please refer to the packaging for the complete ingredient list and any warnings."
        : product.ingredients,
    benefits: item.id === 264
      ? ["Bio-cellulose mask", "Niacinamide, alpha arbutin and coconut water", "Five individually packed sheets"]
      : product.benefits,
    images: gallery,
    sizes: sourceSizes(item),
    priceCents: item.priceCents,
    compareAtCents: undefined,
  };
}

/** Merge source SKUs into existing seed products and append the other source items. */
export function mergeVelorianCatalog(base: SeedProduct[]): SeedProduct[] {
  const existing = base.map((product) => {
    const item = itemBySlug.get(product.slug);
    return item?.matchesExisting ? sourceExistingProduct(product, item) : product;
  });
  return [...existing, ...snapshot.items.filter((item) => !item.matchesExisting).map(newProduct)];
}
