import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  outputFileTracingIncludes: {
    "/api/download": [
      "./src/**/*",
      "./public/**/*",
      "./README.md",
      "./.env.example",
      "./package.json",
      "./package-lock.json",
      "./tsconfig.json",
      "./next.config.ts",
      "./postcss.config.mjs",
      "./eslint.config.mjs",
      "./drizzle.config.ts",
    ],
  },
};

export default nextConfig;
