# V Glow PH storefront

A responsive Next.js storefront with a Velorian product catalog, product pages, reviews, a persistent shopping bag, checkout, and PostgreSQL storage using Drizzle ORM.

## Requirements

- Node.js 20.9 or later (Node.js 22 LTS recommended) and npm.
- A PostgreSQL database that your computer or hosting provider can access.

## Run locally

1. Extract the ZIP and open a terminal in the extracted project folder.
2. Install dependencies with `npm ci`.
3. Copy `.env.example` to `.env` and set `DATABASE_URL` to your PostgreSQL connection string. Never commit or share your actual `.env` file.
4. Apply the database schema with `npx drizzle-kit push`.
5. Start the development server with `npm run dev` and open <http://localhost:3000>.

The demo catalog and example reviews are seeded when the storefront first loads. Existing products, orders, reviews, and subscribers are not included in the download.

## Production deployment

Set `DATABASE_URL` in your hosting provider's environment settings, provision PostgreSQL, apply the schema, then run `npm run build` and `npm start`. Protect your credentials and restrict public access to deployment and admin services.

**Important:** Checkout is a demonstration flow. It stores an order, but does not capture payments, send confirmation emails, fulfill orders, or integrate with a courier. Configure and test actual payment, email, fulfillment, tax, privacy, and security services before accepting real orders.

## Catalog information

The package includes local product images and a snapshot of public Velorian retail listings captured on November 1, 2026, plus earlier demo products. Prices, availability, claims, and supplier details are not automatically synchronized; review and update them before selling. Time-limited source offers automatically stop appearing after their recorded end time. Ensure you have permission to use any third-party product names, photography, and copy.

## What's inside

- `src/app` — pages and server API routes.
- `src/components` — storefront, product, bag, checkout and download components.
- `src/db` — Drizzle schema, catalog and seed data.
- `public/images` — locally stored storefront and product imagery.
- `drizzle.config.ts` and `.env.example` — database setup.

The download deliberately excludes `.env`, environment secrets, `node_modules`, build output, and customer records.
